﻿using Kindergarten.source.api;
using Kindergarten.source.api.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using ToastNotifications;
using ToastNotifications.Lifetime;
using ToastNotifications.Position;

namespace Kindergarten
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class ParentWindow : Window
    {
        private readonly Notifier notifier = new Notifier(cfg =>
        {
            cfg.PositionProvider = new WindowPositionProvider(
                parentWindow: Application.Current.MainWindow,
                corner: Corner.TopRight,
                offsetX: 10,
                offsetY: 10);

            cfg.LifetimeSupervisor = new TimeAndCountBasedLifetimeSupervisor(
                notificationLifetime: TimeSpan.FromSeconds(3),
                maximumNotificationCount: MaximumNotificationCount.FromCount(5));

            cfg.Dispatcher = Application.Current.Dispatcher;
        });

        private readonly Api api = new Api();
        public ParentWindow()
        {
            InitializeComponent();
            FillChidlren();
        }

        private class ShowableChildrenSet : User
        {
            public string Allergies { get; set; }
        }

        public void FillChidlren()
        {
            var children = api.GetChildren();
            List<ShowableChildrenSet> trueChildren = new List<ShowableChildrenSet>();

            foreach (var child in children) {
                trueChildren.Add(new ShowableChildrenSet
                {
                    Age = child.Age,
                    Allergies = String.Join(',', child.Allergies.Select(x => x.Name)),
                    FirstName = child.FirstName,
                    LastName = child.LastName
                });
            }

            ChildrenListBox.ItemsSource = trueChildren;


        }


    }
}
