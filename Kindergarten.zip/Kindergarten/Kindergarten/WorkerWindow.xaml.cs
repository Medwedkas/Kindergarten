﻿using Kindergarten.source.api.models;
using Kindergarten.source.global;
using System.Windows;

namespace Kindergarten
{
    /// <summary>
    /// Interaction logic for Worker.xaml
    /// </summary>
    public partial class WorkerWindow : Window
    {
        public WorkerWindow()
        {
            InitializeComponent();

            var generalInfo = $"{InfoKeeper.User.LastName} {InfoKeeper.User.FirstName} - {((Worker)InfoKeeper.User).Post}";
            var additionalInfo = $"Зарплата: {((Worker)InfoKeeper.User).Salary}₽";

            GeneralInfoLabel.Content = generalInfo;
            AdditionalInfoLabel.Content = additionalInfo;
        }



    }
}
