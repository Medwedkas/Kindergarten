﻿using Kindergarten.source.api.models;

namespace Kindergarten.source.global
{
    public static class InfoKeeper
    {
        public static User User { get; set; } = new User();
    }
}
