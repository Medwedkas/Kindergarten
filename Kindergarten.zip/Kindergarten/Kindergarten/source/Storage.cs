﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

namespace Kindergarten.source
{
    public static class Storage
    {
        public static object LoadValue(string key)
        {
            if (!File.Exists("config.json"))
                return null;

            var raw = File.ReadAllText("config.json");
            dynamic json = JsonConvert.DeserializeObject(raw);

            return json[key];
        }

        public static void SaveValue(string key, object value)
        {
            if (!File.Exists("config.json"))
                File.WriteAllText("config.json", "{}");

            var raw = File.ReadAllText("config.json");
            var json = new Dictionary<string, object>();
            try
            {
                json = JsonConvert.DeserializeObject<Dictionary<string, object>>(raw);
            }
            catch
            {

            }

            json[key] = value;

            File.WriteAllText("config.json", JsonConvert.SerializeObject(json));
        }

        public static void Clear()
        {
            File.WriteAllText("config.json", "{}");
        }
    }
}
