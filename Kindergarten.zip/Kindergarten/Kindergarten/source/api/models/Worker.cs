﻿namespace Kindergarten.source.api.models
{
    public class Worker : User
    {
        public double Salary { get; set; }
        public string Post { get; set; }
    }
}
