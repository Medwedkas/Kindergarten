﻿using System.Collections.Generic;

namespace Kindergarten.source.api.models
{
    public class Child : User
    {
        public List<Allergy> Allergies { get; set; }
    }
}
