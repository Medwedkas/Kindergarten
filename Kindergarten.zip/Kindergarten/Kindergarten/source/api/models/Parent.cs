﻿using Newtonsoft.Json;

namespace Kindergarten.source.api.models
{
    public class Parent : User
    {
        [JsonProperty("document_number")]
        public string DocumentNumber { get; set; }
        public string Contacts { get; set; }
    }
}
