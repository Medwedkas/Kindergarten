﻿namespace Kindergarten.source.api.models
{
    public class Allergy
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
