﻿using Flurl;
using Flurl.Http;
using Kindergarten.source.api.models;
using Kindergarten.source.global;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Kindergarten.source.api
{
    public sealed class Api
    {
        private string api_host => "http://localhost:8000/api";
        private string token => Storage.LoadValue("token").ToString();

        public async Task<bool> Authorization(string username, string password)
        {
            try
            {
                var result = await this.api_host
                                                .AppendPathSegment("create_token")
                                                .PostJsonAsync(new
                                                            {
                                                                username = username,
                                                                password = password
                                                            })
                                                .ReceiveJson<Dictionary<string, object>>();

                if (!(bool)result["status"])
                    return false;

                var response = JsonConvert.DeserializeObject<Dictionary<string, string>>(result["response"].ToString());
                Storage.SaveValue("token", response["token"]);
                this.CheckToken();
                return true;
            }
            catch (Flurl.Http.FlurlHttpException)
            {
                return false;
            }


        }

        public bool CheckToken()
        {
            try
            {
                var raw = this.api_host.AppendPathSegment("get_user_info").WithOAuthBearerToken(token).GetAsync().ReceiveJson<dynamic>().Result;
                var role = (int)raw["response"]["user"]["role"];
                raw = raw["response"]["user"];
                if (role == 1)
                    InfoKeeper.User = JsonConvert.DeserializeObject<Parent>(raw.ToString());
                else if (role == 2)
                    InfoKeeper.User = JsonConvert.DeserializeObject<Worker>(raw.ToString());
                else
                    throw new Exception("Not a valid user role");

                return true;
            }
            catch (Flurl.Http.FlurlHttpException)
            {
                return false;
            }
        }

        public List<Child> GetChildren()
        {
            try
            {
                var raw = this.api_host.AppendPathSegment("get_children").WithOAuthBearerToken(token).GetAsync().ReceiveJson<ChildrenAnswer>().Result;

                return raw.Response["children"];
            }
            catch (Flurl.Http.FlurlHttpException)
            {
                return null;
            }
        }

        private class ChildrenAnswer
        {
            public bool Status { get; set; }
            public Dictionary<string, List<Child>> Response { get; set; }
        }



    }
}
