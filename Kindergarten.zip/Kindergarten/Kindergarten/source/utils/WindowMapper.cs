﻿using System;
using System.Windows;

namespace Kindergarten.source.utils
{
    public static class WindowMapper
    {
        public static Window Map(int role)
        {
            switch (role)
            {
                case 1:
                    return new ParentWindow();
                case 2:
                    return new WorkerWindow();
                default:
                    throw new Exception("Invalid role passed");
            }
        }
    }
}
