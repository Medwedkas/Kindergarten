from source.api.rest import *
from core import web_config

app.run(**web_config)