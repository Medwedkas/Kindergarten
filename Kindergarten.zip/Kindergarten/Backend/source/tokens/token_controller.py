from source.utils import AESCipher
from core import token_config
import json


class TokenController:
    def __init__(self):
        self.aes = AESCipher(key=token_config['secret'])

    def create_token(self, **kwargs) -> str:
        return self.aes.encrypt(json.dumps(kwargs))

    def decrypt_token(self, token: str) -> dict:
        try:
            return json.loads(self.aes.decrypt(token))
        except:
            return {}
