import pymysql
from core import db_config
from hashlib import md5
from source.tokens import TokenController


class DbContext:
    def __init__(self):
        self.conn = pymysql.connect(**db_config, cursorclass=pymysql.cursors.DictCursor)
        self.token_controller = TokenController()

    def get_user_by_username(self, username: str) -> dict:
        with self.conn.cursor() as cursor:
            sql = """
            SELECT u.*, 
            CASE
    WHEN p.id IS NOT NULL 
        THEN 1
    WHEN w.id IS NOT NULL 
        THEN 2
    ELSE -1
END AS role 
             FROM users u
             LEFT JOIN parents p on p.user_id = u.id
             LEFT JOIN workers w on w.user_id = u.id
             WHERE LOWER(`username`)=%s
             LIMIT 1;"""
            cursor.execute(sql, (username,))
            user = cursor.fetchone()

        return {} if not user else user

    def get_worker_by_username(self, username: str) -> dict:
        with self.conn.cursor() as cursor:
            sql = """SELECT w.salary as salary, p.name as post
                     FROM workers w
                     INNER JOIN users u on w.user_id = u.id
                     INNER JOIN posts p on w.post_id = p.id
                     WHERE LOWER(u.username)=%s
                     LIMIT 1;"""
            cursor.execute(sql, (username,))
            user = cursor.fetchone()

        return {} if not user else user

    def get_parent_by_username(self, username: str) -> dict:
        with self.conn.cursor() as cursor:
            sql = """SELECT p.document_number as document_number, p.contacts as contacts
                     FROM parents p
                     INNER JOIN users u on p.user_id = u.id
                     WHERE LOWER(u.username)=%s
                     LIMIT 1;"""
            cursor.execute(sql, (username,))
            user = cursor.fetchone()

        return {} if not user else user

    def create_token(self, username: str, password: str) -> tuple:
        user = self.get_user_by_username(username)
        if user.get('password', '') == md5(password.encode()).hexdigest():
            return True, self.token_controller.create_token(username=username)
        else:
            return False, ''

    def check_token(self, token: str) -> tuple:
        raw = self.token_controller.decrypt_token(token)
        if not raw:
            return False, None

        username = raw['username']
        user = self.get_user_by_username(username)

        if not user:
            return False, None

        return True, user

    def get_parent_children(self, username: str) -> list:
        with self.conn.cursor() as cursor:
            sql = """SELECT c.id, uc.first_name, uc.last_name, uc.age FROM users u
                     JOIN children c on c.parent_id = u.id
                     JOIN users uc on uc.id = c.user_id
                     WHERE LOWER(u.username)=%s
                     LIMIT 1;"""
            cursor.execute(sql, (username,))
            users = cursor.fetchall()
        [x.update({'allergies': self.get_children_allergies(x['id'])}) for x in users]
        return [] if not users else users

    def get_children_allergies(self, child_id: int) -> list:
        with self.conn.cursor() as cursor:
            sql = """SELECT a.id as id, a.name as name FROM children c 
					 JOIN users u on u.id = c.user_id
                     JOIN allergies_rel ar on ar.child_id = c.id 
					 JOIN allergies a on a.id = ar.allergy_id
                     WHERE c.id = %s
                     LIMIT 1;"""
            cursor.execute(sql, (str(child_id),))
            allergies = cursor.fetchall()

        return [] if not allergies else allergies
